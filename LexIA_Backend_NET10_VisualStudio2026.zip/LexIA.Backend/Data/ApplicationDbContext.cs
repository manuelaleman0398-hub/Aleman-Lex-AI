using LexIA.Backend.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LexIA.Backend.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Cliente> Clientes => Set<Cliente>();
    public DbSet<Expediente> Expedientes => Set<Expediente>();
    public DbSet<Actuacion> Actuaciones => Set<Actuacion>();
    public DbSet<Tarea> Tareas => Set<Tarea>();
    public DbSet<Auditoria> Auditorias => Set<Auditoria>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Cliente>()
            .HasIndex(c => c.Correo);

        builder.Entity<Expediente>()
            .HasIndex(e => e.NumeroExpediente);

        builder.Entity<Expediente>()
            .HasOne(e => e.Cliente)
            .WithMany(c => c.Expedientes)
            .HasForeignKey(e => e.ClienteId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<Expediente>()
            .HasOne(e => e.AbogadoResponsable)
            .WithMany()
            .HasForeignKey(e => e.AbogadoResponsableId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<Actuacion>()
            .HasOne(a => a.Expediente)
            .WithMany(e => e.Actuaciones)
            .HasForeignKey(a => a.ExpedienteId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Entity<Tarea>()
            .HasOne(t => t.Expediente)
            .WithMany(e => e.Tareas)
            .HasForeignKey(t => t.ExpedienteId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
