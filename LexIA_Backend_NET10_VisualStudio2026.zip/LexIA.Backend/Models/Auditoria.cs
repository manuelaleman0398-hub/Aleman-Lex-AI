using System.ComponentModel.DataAnnotations;

namespace LexIA.Backend.Models;

public class Auditoria
{
    public long Id { get; set; }

    [Required]
    public string UsuarioId { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Accion { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Entidad { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? EntidadId { get; set; }

    public DateTime Fecha { get; set; } = DateTime.UtcNow;
}
