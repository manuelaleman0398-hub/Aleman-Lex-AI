using System.ComponentModel.DataAnnotations;

namespace LexIA.Backend.Models;

public class Tarea
{
    public int Id { get; set; }

    public int ExpedienteId { get; set; }
    public Expediente? Expediente { get; set; }

    [Required, MaxLength(200)]
    public string Titulo { get; set; } = string.Empty;

    [MaxLength(3000)]
    public string? Descripcion { get; set; }

    [Required]
    public string ResponsableId { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string Prioridad { get; set; } = "Media";

    [Required, MaxLength(30)]
    public string Estado { get; set; } = "Pendiente";

    public DateTime? FechaLimite { get; set; }

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
}
