using System.ComponentModel.DataAnnotations;

namespace LexIA.Backend.Models;

public class Expediente
{
    public int Id { get; set; }

    [MaxLength(100)]
    public string? NumeroExpediente { get; set; }

    public int ClienteId { get; set; }
    public Cliente? Cliente { get; set; }

    [Required, MaxLength(80)]
    public string Materia { get; set; } = string.Empty;

    [Required, MaxLength(150)]
    public string TipoJuicio { get; set; } = string.Empty;

    [MaxLength(250)]
    public string? Juzgado { get; set; }

    [MaxLength(250)]
    public string? Contraparte { get; set; }

    [Required, MaxLength(80)]
    public string EstadoProcesal { get; set; } = "Nuevo";

    public DateOnly FechaInicio { get; set; } = DateOnly.FromDateTime(DateTime.UtcNow);

    [Required]
    public string AbogadoResponsableId { get; set; } = string.Empty;

    public ApplicationUser? AbogadoResponsable { get; set; }

    [MaxLength(4000)]
    public string? Descripcion { get; set; }

    [MaxLength(4000)]
    public string? Observaciones { get; set; }

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public string? UsuarioCreacionId { get; set; }

    public bool Archivado { get; set; } = false;

    public ICollection<Actuacion> Actuaciones { get; set; } = new List<Actuacion>();
    public ICollection<Tarea> Tareas { get; set; } = new List<Tarea>();
}
