using System.ComponentModel.DataAnnotations;

namespace LexIA.Backend.Models;

public class Actuacion
{
    public int Id { get; set; }

    public int ExpedienteId { get; set; }
    public Expediente? Expediente { get; set; }

    public DateOnly Fecha { get; set; }

    [Required, MaxLength(120)]
    public string Tipo { get; set; } = string.Empty;

    [Required, MaxLength(5000)]
    public string Descripcion { get; set; } = string.Empty;

    [MaxLength(2000)]
    public string? ProximaAccion { get; set; }

    public string UsuarioRegistroId { get; set; } = string.Empty;

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;
}
