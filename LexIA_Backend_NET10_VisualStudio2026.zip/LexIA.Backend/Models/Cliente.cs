using System.ComponentModel.DataAnnotations;

namespace LexIA.Backend.Models;

public class Cliente
{
    public int Id { get; set; }

    [Required, MaxLength(100)]
    public string Nombre { get; set; } = string.Empty;

    [Required, MaxLength(150)]
    public string Apellidos { get; set; } = string.Empty;

    [MaxLength(30)]
    public string? Telefono { get; set; }

    [EmailAddress, MaxLength(200)]
    public string? Correo { get; set; }

    [MaxLength(500)]
    public string? Domicilio { get; set; }

    [MaxLength(18)]
    public string? Curp { get; set; }

    [MaxLength(13)]
    public string? Rfc { get; set; }

    [MaxLength(2000)]
    public string? Observaciones { get; set; }

    public DateTime FechaRegistro { get; set; } = DateTime.UtcNow;

    public bool Activo { get; set; } = true;

    public ICollection<Expediente> Expedientes { get; set; } = new List<Expediente>();
}
