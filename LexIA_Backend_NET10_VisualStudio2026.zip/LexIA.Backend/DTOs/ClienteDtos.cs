namespace LexIA.Backend.DTOs;

public record ClienteRequest(
    string Nombre,
    string Apellidos,
    string? Telefono,
    string? Correo,
    string? Domicilio,
    string? Curp,
    string? Rfc,
    string? Observaciones);
