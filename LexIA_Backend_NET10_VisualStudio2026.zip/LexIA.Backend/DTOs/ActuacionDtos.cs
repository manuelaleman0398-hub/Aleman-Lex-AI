namespace LexIA.Backend.DTOs;

public record ActuacionRequest(
    int ExpedienteId,
    DateOnly Fecha,
    string Tipo,
    string Descripcion,
    string? ProximaAccion);
