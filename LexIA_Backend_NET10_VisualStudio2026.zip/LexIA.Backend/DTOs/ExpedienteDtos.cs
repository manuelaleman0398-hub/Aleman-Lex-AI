namespace LexIA.Backend.DTOs;

public record ExpedienteRequest(
    string? NumeroExpediente,
    int ClienteId,
    string Materia,
    string TipoJuicio,
    string? Juzgado,
    string? Contraparte,
    string EstadoProcesal,
    DateOnly FechaInicio,
    string AbogadoResponsableId,
    string? Descripcion,
    string? Observaciones);
