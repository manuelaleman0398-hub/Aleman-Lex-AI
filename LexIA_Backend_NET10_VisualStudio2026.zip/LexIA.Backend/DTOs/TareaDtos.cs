namespace LexIA.Backend.DTOs;

public record TareaRequest(
    int ExpedienteId,
    string Titulo,
    string? Descripcion,
    string ResponsableId,
    string Prioridad,
    string Estado,
    DateTime? FechaLimite);
