namespace LexIA.Backend.DTOs;

public record LoginRequest(string Email, string Password);

public record RegisterUserRequest(
    string Nombre,
    string Apellidos,
    string Email,
    string Password,
    string Rol);

public record AuthResponse(
    string Token,
    DateTime Expira,
    string Nombre,
    string Email,
    IEnumerable<string> Roles);
