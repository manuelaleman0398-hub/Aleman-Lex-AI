using System.Security.Claims;
using LexIA.Backend.Data;
using LexIA.Backend.DTOs;
using LexIA.Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LexIA.Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ExpedientesController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public ExpedientesController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var expedientes = await _db.Expedientes
            .AsNoTracking()
            .Where(e => !e.Archivado)
            .Include(e => e.Cliente)
            .Include(e => e.AbogadoResponsable)
            .OrderByDescending(e => e.FechaCreacion)
            .Select(e => new
            {
                e.Id,
                e.NumeroExpediente,
                Cliente = e.Cliente == null
                    ? null
                    : e.Cliente.Nombre + " " + e.Cliente.Apellidos,
                e.Materia,
                e.TipoJuicio,
                e.Juzgado,
                e.Contraparte,
                e.EstadoProcesal,
                e.FechaInicio,
                Abogado = e.AbogadoResponsable == null
                    ? null
                    : e.AbogadoResponsable.Nombre + " " + e.AbogadoResponsable.Apellidos
            })
            .ToListAsync();

        return Ok(expedientes);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var expediente = await _db.Expedientes
            .AsNoTracking()
            .Include(e => e.Cliente)
            .Include(e => e.AbogadoResponsable)
            .Include(e => e.Actuaciones.OrderByDescending(a => a.Fecha))
            .Include(e => e.Tareas.OrderBy(t => t.FechaLimite))
            .FirstOrDefaultAsync(e => e.Id == id && !e.Archivado);

        return expediente is null ? NotFound() : Ok(expediente);
    }

    [HttpPost]
    [Authorize(Roles = "Administrador,Abogado")]
    public async Task<IActionResult> Create(ExpedienteRequest request)
    {
        if (!await _db.Clientes.AnyAsync(c => c.Id == request.ClienteId && c.Activo))
            return BadRequest(new { mensaje = "El cliente indicado no existe." });

        if (!await _db.Users.AnyAsync(u => u.Id == request.AbogadoResponsableId && u.Activo))
            return BadRequest(new { mensaje = "El abogado responsable no existe." });

        var usuarioActual = User.FindFirstValue(ClaimTypes.NameIdentifier);

        var expediente = new Expediente
        {
            NumeroExpediente = request.NumeroExpediente,
            ClienteId = request.ClienteId,
            Materia = request.Materia,
            TipoJuicio = request.TipoJuicio,
            Juzgado = request.Juzgado,
            Contraparte = request.Contraparte,
            EstadoProcesal = request.EstadoProcesal,
            FechaInicio = request.FechaInicio,
            AbogadoResponsableId = request.AbogadoResponsableId,
            Descripcion = request.Descripcion,
            Observaciones = request.Observaciones,
            UsuarioCreacionId = usuarioActual
        };

        _db.Expedientes.Add(expediente);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = expediente.Id }, expediente);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "Administrador,Abogado")]
    public async Task<IActionResult> Update(int id, ExpedienteRequest request)
    {
        var expediente = await _db.Expedientes.FindAsync(id);

        if (expediente is null || expediente.Archivado)
            return NotFound();

        expediente.NumeroExpediente = request.NumeroExpediente;
        expediente.ClienteId = request.ClienteId;
        expediente.Materia = request.Materia;
        expediente.TipoJuicio = request.TipoJuicio;
        expediente.Juzgado = request.Juzgado;
        expediente.Contraparte = request.Contraparte;
        expediente.EstadoProcesal = request.EstadoProcesal;
        expediente.FechaInicio = request.FechaInicio;
        expediente.AbogadoResponsableId = request.AbogadoResponsableId;
        expediente.Descripcion = request.Descripcion;
        expediente.Observaciones = request.Observaciones;

        await _db.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Administrador,Abogado")]
    public async Task<IActionResult> Archive(int id)
    {
        var expediente = await _db.Expedientes.FindAsync(id);

        if (expediente is null)
            return NotFound();

        expediente.Archivado = true;
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
