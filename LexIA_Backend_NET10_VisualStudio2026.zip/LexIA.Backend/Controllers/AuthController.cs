using LexIA.Backend.DTOs;
using LexIA.Backend.Models;
using LexIA.Backend.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace LexIA.Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly JwtTokenService _jwt;

    public AuthController(
        UserManager<ApplicationUser> userManager,
        JwtTokenService jwt)
    {
        _userManager = userManager;
        _jwt = jwt;
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var user = await _userManager.FindByEmailAsync(request.Email);

        if (user is null || !user.Activo)
            return Unauthorized(new { mensaje = "Credenciales inválidas." });

        if (!await _userManager.CheckPasswordAsync(user, request.Password))
            return Unauthorized(new { mensaje = "Credenciales inválidas." });

        var roles = await _userManager.GetRolesAsync(user);
        var (token, expira) = _jwt.CreateToken(user, roles);

        return Ok(new AuthResponse(
            token,
            expira,
            $"{user.Nombre} {user.Apellidos}",
            user.Email ?? string.Empty,
            roles));
    }

    [HttpPost("usuarios")]
    [Authorize(Roles = "Administrador")]
    public async Task<IActionResult> RegistrarUsuario(RegisterUserRequest request)
    {
        var rolesValidos = new[] { "Administrador", "Abogado", "Asistente" };

        if (!rolesValidos.Contains(request.Rol))
            return BadRequest(new { mensaje = "Rol inválido." });

        if (await _userManager.FindByEmailAsync(request.Email) is not null)
            return Conflict(new { mensaje = "El correo ya está registrado." });

        var user = new ApplicationUser
        {
            Nombre = request.Nombre,
            Apellidos = request.Apellidos,
            Email = request.Email,
            UserName = request.Email,
            Activo = true
        };

        var result = await _userManager.CreateAsync(user, request.Password);

        if (!result.Succeeded)
            return BadRequest(result.Errors);

        await _userManager.AddToRoleAsync(user, request.Rol);

        return Created("", new
        {
            user.Id,
            user.Nombre,
            user.Apellidos,
            user.Email,
            Rol = request.Rol
        });
    }
}
