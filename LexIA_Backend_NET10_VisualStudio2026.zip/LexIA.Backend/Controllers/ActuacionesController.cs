using System.Security.Claims;
using LexIA.Backend.Data;
using LexIA.Backend.DTOs;
using LexIA.Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LexIA.Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ActuacionesController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public ActuacionesController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet("expediente/{expedienteId:int}")]
    public async Task<IActionResult> GetByExpediente(int expedienteId)
    {
        var items = await _db.Actuaciones
            .AsNoTracking()
            .Where(a => a.ExpedienteId == expedienteId)
            .OrderByDescending(a => a.Fecha)
            .ThenByDescending(a => a.FechaCreacion)
            .ToListAsync();

        return Ok(items);
    }

    [HttpPost]
    [Authorize(Roles = "Administrador,Abogado,Asistente")]
    public async Task<IActionResult> Create(ActuacionRequest request)
    {
        if (!await _db.Expedientes.AnyAsync(e =>
                e.Id == request.ExpedienteId && !e.Archivado))
        {
            return BadRequest(new { mensaje = "El expediente no existe." });
        }

        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

        if (string.IsNullOrWhiteSpace(userId))
            return Unauthorized();

        var actuacion = new Actuacion
        {
            ExpedienteId = request.ExpedienteId,
            Fecha = request.Fecha,
            Tipo = request.Tipo,
            Descripcion = request.Descripcion,
            ProximaAccion = request.ProximaAccion,
            UsuarioRegistroId = userId
        };

        _db.Actuaciones.Add(actuacion);
        await _db.SaveChangesAsync();

        return Created("", actuacion);
    }
}
