using LexIA.Backend.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LexIA.Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class DashboardController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public DashboardController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var ahora = DateTime.UtcNow;
        var proximos7Dias = ahora.AddDays(7);

        var expedientesActivos = await _db.Expedientes
            .CountAsync(e => !e.Archivado &&
                e.EstadoProcesal != "Concluido");

        var tareasPendientes = await _db.Tareas
            .CountAsync(t => t.Estado == "Pendiente" || t.Estado == "En proceso");

        var tareasProximas = await _db.Tareas
            .AsNoTracking()
            .Where(t =>
                t.FechaLimite != null &&
                t.FechaLimite >= ahora &&
                t.FechaLimite <= proximos7Dias &&
                t.Estado != "Terminada" &&
                t.Estado != "Cancelada")
            .OrderBy(t => t.FechaLimite)
            .Take(10)
            .ToListAsync();

        return Ok(new
        {
            expedientesActivos,
            tareasPendientes,
            tareasProximas
        });
    }
}
