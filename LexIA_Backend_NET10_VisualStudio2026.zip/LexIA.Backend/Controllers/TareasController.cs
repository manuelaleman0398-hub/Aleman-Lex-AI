using LexIA.Backend.Data;
using LexIA.Backend.DTOs;
using LexIA.Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LexIA.Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class TareasController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public TareasController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var tareas = await _db.Tareas
            .AsNoTracking()
            .OrderBy(t => t.FechaLimite)
            .ToListAsync();

        return Ok(tareas);
    }

    [HttpPost]
    public async Task<IActionResult> Create(TareaRequest request)
    {
        var tarea = new Tarea
        {
            ExpedienteId = request.ExpedienteId,
            Titulo = request.Titulo,
            Descripcion = request.Descripcion,
            ResponsableId = request.ResponsableId,
            Prioridad = request.Prioridad,
            Estado = request.Estado,
            FechaLimite = request.FechaLimite
        };

        _db.Tareas.Add(tarea);
        await _db.SaveChangesAsync();

        return Created("", tarea);
    }

    [HttpPatch("{id:int}/estado")]
    public async Task<IActionResult> CambiarEstado(int id, [FromBody] string estado)
    {
        var estadosValidos = new[] { "Pendiente", "En proceso", "Terminada", "Cancelada" };

        if (!estadosValidos.Contains(estado))
            return BadRequest(new { mensaje = "Estado inválido." });

        var tarea = await _db.Tareas.FindAsync(id);

        if (tarea is null)
            return NotFound();

        tarea.Estado = estado;
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
