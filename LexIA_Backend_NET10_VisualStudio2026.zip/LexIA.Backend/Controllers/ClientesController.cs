using LexIA.Backend.Data;
using LexIA.Backend.DTOs;
using LexIA.Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LexIA.Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ClientesController : ControllerBase
{
    private readonly ApplicationDbContext _db;

    public ClientesController(ApplicationDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? buscar)
    {
        var query = _db.Clientes
            .AsNoTracking()
            .Where(c => c.Activo)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(buscar))
        {
            var term = buscar.Trim().ToLower();

            query = query.Where(c =>
                c.Nombre.ToLower().Contains(term) ||
                c.Apellidos.ToLower().Contains(term) ||
                (c.Telefono != null && c.Telefono.Contains(term)) ||
                (c.Correo != null && c.Correo.ToLower().Contains(term)));
        }

        return Ok(await query
            .OrderBy(c => c.Apellidos)
            .ThenBy(c => c.Nombre)
            .ToListAsync());
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var cliente = await _db.Clientes
            .AsNoTracking()
            .Include(c => c.Expedientes)
            .FirstOrDefaultAsync(c => c.Id == id && c.Activo);

        return cliente is null ? NotFound() : Ok(cliente);
    }

    [HttpPost]
    [Authorize(Roles = "Administrador,Abogado,Asistente")]
    public async Task<IActionResult> Create(ClienteRequest request)
    {
        var cliente = new Cliente
        {
            Nombre = request.Nombre,
            Apellidos = request.Apellidos,
            Telefono = request.Telefono,
            Correo = request.Correo,
            Domicilio = request.Domicilio,
            Curp = request.Curp,
            Rfc = request.Rfc,
            Observaciones = request.Observaciones
        };

        _db.Clientes.Add(cliente);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = cliente.Id }, cliente);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "Administrador,Abogado,Asistente")]
    public async Task<IActionResult> Update(int id, ClienteRequest request)
    {
        var cliente = await _db.Clientes.FindAsync(id);

        if (cliente is null || !cliente.Activo)
            return NotFound();

        cliente.Nombre = request.Nombre;
        cliente.Apellidos = request.Apellidos;
        cliente.Telefono = request.Telefono;
        cliente.Correo = request.Correo;
        cliente.Domicilio = request.Domicilio;
        cliente.Curp = request.Curp;
        cliente.Rfc = request.Rfc;
        cliente.Observaciones = request.Observaciones;

        await _db.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = "Administrador,Abogado")]
    public async Task<IActionResult> Archive(int id)
    {
        var cliente = await _db.Clientes.FindAsync(id);

        if (cliente is null)
            return NotFound();

        cliente.Activo = false;
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
